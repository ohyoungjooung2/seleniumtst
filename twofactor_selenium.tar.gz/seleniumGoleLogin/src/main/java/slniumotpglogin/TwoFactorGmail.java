package slniumotpglogin;
//import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class TwoFactorGmail {
 
	static WebDriver driver;
	public static void gmailSignIn() {
		System.setProperty("webdriver.gecko.driver","drivers/geckodriver");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://accounts.google.com/signin");
		driver.findElement(By.id("identifierId")).sendKeys("login");
		driver.findElement(By.id("identifierNext")).click();
		driver.findElement(By.name("password")).sendKeys("key");
		driver.findElement(By.id("passwordNext")).click();
		
		//Otp value is returned from getTwoFactor method
		driver.findElement(By.id("totpPin")).sendKeys(TOTPGenerator.getTwoFactorCode());
		driver.findElement(By.id("totpNext")).click();

	}
	public static void main(String[] args) throws InterruptedException {
		TwoFactorGmail gsignin = new TwoFactorGmail();
		gsignin.gmailSignIn();
	}
}