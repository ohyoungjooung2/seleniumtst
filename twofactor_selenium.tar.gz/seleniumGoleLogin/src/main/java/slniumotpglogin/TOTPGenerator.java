package slniumotpglogin;
import org.jboss.aerogear.security.otp.Totp;

public class TOTPGenerator {
	
	public static String getTwoFactorCode() {
		//google otp security key(time based)
		Totp totp = new Totp("uwxtkxc2moosk3sddtrxfsk765x253v6");
		String twoFactorCode = totp.now(); //Generated 2FA code here
		return twoFactorCode;
	}

}
